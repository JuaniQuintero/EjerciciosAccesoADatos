package clase3del11;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class InvocarProcedimiento2 {

	public static void main(String[] args) {
		Connection conn=null;
		CallableStatement cstmt = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/phonelandCompleta2","root","admin");
			cstmt= conn.prepareCall("call CalculaEdad(?,?)");
			cstmt.setInt(1, 19);
			cstmt.registerOutParameter(2, Types.INTEGER);
			cstmt.execute();
			
			int edad = cstmt.getInt(2);
			System.out.println("El año es: " + edad);
			conn.close();
		}catch(SQLException e) {
			
		}
	}

}
