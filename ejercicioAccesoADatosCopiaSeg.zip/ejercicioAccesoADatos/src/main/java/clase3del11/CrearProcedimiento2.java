package clase3del11;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CrearProcedimiento2 {

	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement prepa = null;
		String dropProcedure = "DROP PROCEDURE IF EXISTS ObtenerCLientesMayor2";
		String procedure = "CREATE PROCEDURE ObtenerCLientesMayor2() "
				+ "BEGIN "
				+ "SELECT * FROM clientes WHERE id>=2;"
				+ "END;";
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa","root","admin");
			prepa = conn.prepareStatement(dropProcedure);
			prepa.executeUpdate();
			prepa = conn.prepareStatement(procedure);
			prepa.executeUpdate();
			System.out.println("Proceso creado");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
