package accesoADatosSimulacro;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;

public class Simulacro {

	public static void main(String[] args) {
		boolean salir = false;
		Scanner sc = new Scanner(System.in);
		while(!salir){
			System.out.println("1 - Crear carpeta\n"
					+ "2 - Crear Fichero\n"
					+ "3 - Borrar Fichero\n"
					+ "4 - Borrar Carperta\n"
					+ "5 - Leer Fichero\n"
					+ "6 - Ver Información"
					+ "7 - Salir");
			byte eleccion = Byte.parseByte(sc.nextLine());
			switch(eleccion) {
			case 1:
				File carpeta = new File("c:\\carpetaSimulacro");
				if(carpeta.exists()) {
					System.out.println("La carpeta ya existe");
				}else {
					carpeta.mkdir();
					System.out.println("Carpeta creada");
				}
				break;
			case 2:
				File archivo = new File("c:\\carpetaSimulacro\\ficherosimulacro");
				try {
					BufferedWriter bw = new BufferedWriter (new FileWriter(archivo));
					System.out.println("Archivo creado correctamente");
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
			case 3:
				File fichero = new File("c:\\carpetaSimulacro\\ficherosimulacro");
				if(fichero.exists()) {
					boolean borrado = fichero.delete();
					if (borrado) {
						System.out.println("El fichero ha sido borrado");
					}else {
						System.out.println("No se pudo borrar el fichero");
					}
				}else {
					System.out.println("El fichero no existe");
				}
				break;
			case 4:
				File carpeta2 = new File("c:\\carpetaSimulacro\\");
				if (carpeta2.exists()&&carpeta2.isDirectory()) {
					System.out.println("El directorio existe");
					try {
						FileUtils.deleteDirectory(carpeta2);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					System.out.println("El directorio no existe");
				}
				break;
			case 5:
				try {
					File archivo2 = new File("c:\\carpetaSimulacro\\ficheroSimulacro");
					if(!archivo2.exists()) {
						System.out.println("El archivo no existe");
						return;
					}
					FileReader fr = new FileReader(archivo2);
					BufferedReader br = new BufferedReader(fr);
					String linea;
					while((linea=br.readLine())!=null) {
						System.out.println(linea);
					}
				}catch(IOException e) {
					e.printStackTrace();
				}
				break;
			case 6:
				File direc = new File("c:\\carpetaSimulacro\\");
				System.out.println("Nombre del directorio: "+ direc.getName());
				System.out.println("Ruta: "+ direc.getPath());
				System.out.println("Ruta absoluta: "+ direc.getAbsolutePath());
				System.out.println("Lectura: "+ direc.canRead());
				System.out.println("Escritura: "+ direc.canWrite());
				System.out.println("Tamaño: "+ direc.length() + "Kb");
				System.out.println("Es un directorio?: "+ direc.isDirectory());
				System.out.println("Es un fichero?: "+ direc.isFile());
				System.out.println("Nombre del directorio: "+ direc.getParent());
				break;
			case 7:
				salir=true;
				break;
			default:
				System.out.println("El número no existe");
				break;
			}
		}
	}

}
