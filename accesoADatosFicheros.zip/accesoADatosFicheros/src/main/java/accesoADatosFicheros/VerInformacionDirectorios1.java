package accesoADatosFicheros;

import java.io.File;

public class VerInformacionDirectorios1 {
	public static void main(String []args) {
		File direc = new File(".\\src\\main\\java\\accesoADatosFicheros\\VerInformacionDirectorios1.java");
		System.out.println("INFORMACIÓN SOBRE EL DIRECTORIO:");
		if(direc.exists()) {
			System.out.println("Nombre del directorio: "+ direc.getName());
			System.out.println("Ruta: "+ direc.getPath());
			System.out.println("Ruta absoluta: "+ direc.getAbsolutePath());
			System.out.println("Lectura: "+ direc.canRead());
			System.out.println("Escritura: "+ direc.canWrite());
			System.out.println("Tamaño: "+ direc.length() + "Kb");
			System.out.println("Es un directorio?: "+ direc.isDirectory());
			System.out.println("Es un fichero?: "+ direc.isFile());
			System.out.println("Nombre del directorio: "+ direc.getParent());
			
		}
	}
}
