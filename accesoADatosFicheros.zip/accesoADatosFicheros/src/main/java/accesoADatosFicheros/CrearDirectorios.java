package accesoADatosFicheros;

import java.io.File;

public class CrearDirectorios {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ruta =".\\src\\";
		String ruta2="c:\\";
		String carpeta="pruebaCreacion";
		String carpeta2="prueba";
		File direc = new File(ruta2+carpeta2);
		if(direc.exists()==true) {
			System.out.println("La carpeta ya existe *insertar insulto a gusto*");
		}else {
			direc.mkdir();
			System.out.println("Carpeta creada");
		}
	}

}
