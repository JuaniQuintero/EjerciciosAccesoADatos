package accesoADatosFicheros;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
public class BorrarCarpeta {

	public static void main(String[] args) {
		File carpeta = new File(".\\src\\main\\java\\NEWDIREC");
		if (carpeta.exists()&&carpeta.isDirectory()) {
			System.out.println("El directorio existe");
			try {
				FileUtils.deleteDirectory(carpeta);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			System.out.println("El directorio no existe");
		}
	}

}
