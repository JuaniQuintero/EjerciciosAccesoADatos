package ficherosTexto;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EjercicioCrearFicheroConTexto {
	public static void main(String[] args) {
		String ruta ="c:\\prueba\\";
		String nombreArchivo="granada.txt";
		String contenido ="uwu";
		try {
			BufferedWriter bw = new BufferedWriter (new FileWriter(ruta+nombreArchivo));
			System.out.println("Archivo creado correctamente");
			bw.write(contenido);
			bw.close();
		}catch(IOException e) {
			e.printStackTrace();
			System.err.println("Error al crear el archivo");
		}
	}
}
