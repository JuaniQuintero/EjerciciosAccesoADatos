package ficherosTexto;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CrearFicheroCiudades {
	public static void main(String[] args) {
		String ruta ="c:\\prueba\\";
		String nombreArchivo="ciudades.txt";
		String [] contenido = {"Córdoba","Málaga","Sevilla","Cádiz","Huelva","Jaen"};
		try {
			BufferedWriter bw = new BufferedWriter (new FileWriter(ruta+nombreArchivo));
			System.out.println("Archivo creado correctamente");
			for(String cont : contenido) {
				bw.write(cont+"\n");
			}
			bw.close();
		}catch(IOException e) {
			e.printStackTrace();
			System.err.println("Error al crear el archivo");
		}
	}
}
