package ficherosTexto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class EjercicioLeerArchivos {
	public static void main(String []args) {
		try {
			File archivo = new File("c:/prueba/ciudades.txt");
			if(!archivo.exists()) {
				System.out.println("El archivo no existe");
				return;
			}
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
			String linea;
			while((linea=br.readLine())!=null) {
				System.out.println(linea);
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
